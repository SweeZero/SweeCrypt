# SweeCrypt
A basic and fun encryption module for everyone.

This module has not been publish to PyPi yet, but we'll work on it!
